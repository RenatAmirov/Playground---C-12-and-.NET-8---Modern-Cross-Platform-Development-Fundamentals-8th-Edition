﻿namespace Packt.Shared;

public static class Viper
{
  // Define an array of Viper pilot call signs.
  public static string[] Callsigns = new[]
  {
    "Husker", "Starbuck", "Apollo", "Boomer",
    "Bulldog", "Athena", "Helo", "Racetrack"
  };
}
