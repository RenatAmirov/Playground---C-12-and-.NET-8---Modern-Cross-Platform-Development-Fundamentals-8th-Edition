﻿namespace Texas
{
  public class Paris
  {
  }
}
