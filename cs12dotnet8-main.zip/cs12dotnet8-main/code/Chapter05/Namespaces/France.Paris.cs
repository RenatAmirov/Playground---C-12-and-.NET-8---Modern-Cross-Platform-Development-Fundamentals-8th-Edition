﻿namespace France
{
  public class Paris
  {
  }
}
