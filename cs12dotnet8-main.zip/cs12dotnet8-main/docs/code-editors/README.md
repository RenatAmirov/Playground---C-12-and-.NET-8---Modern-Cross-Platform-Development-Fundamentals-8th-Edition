# Code Editors
- [Visual Studio 2022 for Windows](vs4win.md)
- [Visual Studio Code](vscode.md)
- [JetBrains Rider](rider.md)

> **Warning!** Visual Studio 2022 for Mac will reach end-of-life in August 2024. You should switch to an alternative as soon as possible. You can read the retirement announcement at the following link: https://devblogs.microsoft.com/visualstudio/visual-studio-for-mac-retirement-announcement/.

- [Visual Studio 2022 for Mac](vs4mac.md)
